package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bank.entity.Admin;
import com.bank.service.IBankService;


@Controller
public class BankController {

@Autowired
private IBankService bankService;
@RequestMapping("/index")
public String dummy(Model model){
	
	return "index";
}
	
@RequestMapping("/admin")
 	public String adminLogin(Model model) 
	{
	//model.addAttribute("transactionList",bankService.loadAll());
		model.addAttribute("admin",new Admin());
		
		return "adminlogin";
	}

}
