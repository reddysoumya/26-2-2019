package com.bank.dao;

public class BankRepositoryImpl implements IBankRepository {

}
