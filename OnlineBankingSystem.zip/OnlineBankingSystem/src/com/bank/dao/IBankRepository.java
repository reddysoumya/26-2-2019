package com.bank.dao;

public interface IBankRepository {

}
