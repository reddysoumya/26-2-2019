package com.bank.entity;

//****************Importing Required Packages********************************//
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

//*******************************ADMIN ENTITY CLASS****************************//
@Entity
public class Admin {
	
	
	@Id           //AdminId as a Primary Key
	@Column       //adminId as a column name
	private int adminId;
	@Column       //password as a column name
	private String password;
	
//*****************Generating getters and setters*****************************//
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
