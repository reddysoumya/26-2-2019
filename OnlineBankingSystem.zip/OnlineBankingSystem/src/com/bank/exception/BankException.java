package com.bank.exception;

public class BankException {

}
