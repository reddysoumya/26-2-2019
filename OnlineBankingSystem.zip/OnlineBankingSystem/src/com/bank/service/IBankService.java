package com.bank.service;

public interface IBankService {

}
